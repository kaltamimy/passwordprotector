from django.contrib import admin
from .models import Password, User
# Models registered here. Username/password loaded into admin database- admin can track/manage users
admin.site.register(User)
admin.site.register(Password)