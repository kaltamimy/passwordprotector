from django.urls import path

from . import views
from . import api

from django.conf import settings
from django.conf.urls.static import static

from password.api import save_credentials_api, get_credentials_api, delete_credentials_api

urlpatterns = [
# Views that user can see.
    path('signup/', views.signup_view, name='signup'),
    path('', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('home/', views.home_view, name='home'),
    path('home/save', views.home_view, name='save'),
    path('home/reveal', views.home_view, name='reveal'),
    path('home/sites', views.home_view, name='sites'),
# Allows tasks such as querying, getting, posting, etc.
    path('api/save/', save_credentials_api, name="save api"),
    path('api/get/', get_credentials_api, name="get api"),
    path('api/delete/', delete_credentials_api, name="delete api"),
]