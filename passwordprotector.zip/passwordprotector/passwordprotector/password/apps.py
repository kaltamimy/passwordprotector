from django.apps import AppConfig

# 'AppConfig' is subclass of 'PasswordConfig', Django can load class without specifying path to config class.
class PasswordConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'password'