from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.auth import authenticate, login, logout

from password.forms import UserForm
from .models import Password, User

# Create your views here. User redirected to homepage.
def home_view(request):
    return render(request, 'password/home.html',{
        'title': "Home",
    })
# Before accessing homepage, user redirected to log in
def login_view(request):
    if request.method == "POST":
        user = authenticate(
            request,
            username=request.POST['username'],
            password=request.POST['password'],
        )
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return HttpResponse("Invalid credentials")
# Sometimes initial selection is not 'POST'. Prevents program from halting + redirects user to correct page.
    return render(request, 'password/login.html', {
        'form': UserForm()
    })
# User no longer validated.
def logout_view(request):
    logout(request)
    return redirect('login')
# User inputs new credentials to be saved to database. Malicious hacking attempts blocked so no special characters used; only passwords.
def signup_view(request):
    form = UserForm()
    if request.method == "POST":
        form = UserForm(request.POST)
        if form.is_valid():
            user = form.save()
            user.set_password(form.cleaned_data['password'])
            user.save()
            login(request, user)
            return home_view(request)
    return render(request, 'password/signup.html', {
        'form': form,
    })