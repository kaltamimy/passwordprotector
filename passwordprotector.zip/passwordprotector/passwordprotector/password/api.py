from django.http import JsonResponse
from django.http.response import HttpResponse
from django.shortcuts import get_object_or_404
from datetime import date
import base64
import json
import io
from django.core.files.images import ImageFile
from django.contrib import messages

from .models import User, Password
# Queries all credentials in database, then identifies exact one. 'Delete' request sent which removes entrance from database.
def delete_credentials_api(request):
    if request.method == "DELETE":
            body = json.loads(request.body)
            cred = get_object_or_404(Password, _username=body['username'], _password=body['password'], _websiteName=body['website'])
            cred.delete()
            return JsonResponse({
                'sent': ""
            })
# 'Password' object is all credentials. Credentials are taken in and added to user's list.
def save_credentials_api(request):
    '''
        API entry point for list of passwords
        On POST: Create a new password
        ON GET: Get a list of all passwords
    '''

    if request.method == "POST":
        body = json.loads(request.body)
        if body != {}:
            username = body['username']
            password = body['password']
            website = body['website']
            p = Password.objects.create(
                _username=username,
                _password=password,
                _websiteName=website
                )
            request.user.passwords.add(p)
            return JsonResponse({
                'usernames': username
            })
# Iterates through credentials fields, then appends to array which returns as Json.
def get_credentials_api(request):
    if request.method == "GET":
        queryset = Password.objects.all()
        resp = queryset.filter(user=request.user)
        userData = []
        for x in resp:
            userData.append(
                { 'user': x._username,
                'pass' : x._password,
                'site' : x._websiteName,
                }
            )
        return JsonResponse({ 'myData' : userData, "name" : str(request.user)  })