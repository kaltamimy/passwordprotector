from django import forms
from django.forms import ModelForm

from password.models import User
# Username/password entered by user are saved to database.
class UserForm(ModelForm):
    class Meta:
        model = User
        fields = ['username', 'password']