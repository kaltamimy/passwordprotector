from django.db import models
from django.contrib.auth.models import AbstractUser
# Create your models here.
# Credentials are added here.
class Password(models.Model):
    _username = models.CharField(max_length=200)
    _password = models.CharField(max_length=200)
    _websiteName = models.CharField(max_length=200)
# If admin wants to print out a specific credential, it is returned to them here.
    def to_dict(self):
        return {
            'id': self.id
        }
# User is created. Abstract user comes with pre-loaded fields: ID, username, password.
class User(AbstractUser):
    passwords = models.ManyToManyField(Password)

    def to_dict(self):
        return {
            'id': self.id
        }